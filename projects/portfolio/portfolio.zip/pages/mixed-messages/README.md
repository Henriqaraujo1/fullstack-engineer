# First project Portfolio
My first Project of codeacademy, to create a random message, the ideia was to create a script to show messages randonly, but I want to show that message on the webpage, i have less skills about HTML  and CSS:

1. I choice the phrases to put in the messages
	2. about day of the week, Motivation phrases and Country to next travel
2.  I create the webpage and use some styles with CSS
3. I finally create the script

